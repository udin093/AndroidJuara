package com.example.jurusancompose.model

import android.os.Parcel
import android.os.Parcelable
import com.example.jurusancompose.R

data class Universitas(
    val namaUniversitas: String,
    val Daerah: String,
    val photoUniversitas: Int
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(namaUniversitas)
        parcel.writeString(Daerah)
        parcel.writeInt(photoUniversitas)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Jurusan> {
        override fun createFromParcel(parcel: Parcel): Jurusan {
            return Jurusan(parcel)
        }

        override fun newArray(size: Int): Array<Jurusan?> {
            return arrayOfNulls(size)
        }
    }
}

object DataUniversitas {
    val infoUniversitas= listOf(
        Universitas(
            "Universitas Andalas",
            "Kota Padang",
            R.drawable.unand
        ),
        Universitas(
            "Universitas Indonesia",
            "Kota Depok",
            R.drawable.ui
        ),
        Universitas(
            "ITB",
            "Kota Bandung",
            R.drawable.itb
        ),
        Universitas(
            "UGM",
            "Kota yogyakarta",
            R.drawable.ugm

        ),
        Universitas(
            "Unnes",
            "Kota Semarang",
            R.drawable.unnes
        ),

    )
}