package com.example.jurusancompose.navigation

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.jurusancompose.main.DetailActivity
import com.example.jurusancompose.model.DataJurusan
import com.example.jurusancompose.model.DataUniversitas
import com.example.jurusancompose.model.Jurusan
import com.example.jurusancompose.model.Universitas

@Composable
fun DetailJurusanScreen(jurusan: Jurusan, onBackClick: () -> Unit) {

    val context = LocalContext.current

    Column(modifier = Modifier
        .fillMaxSize()) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 30.dp, top = 25.dp, end = 10.dp, bottom = 25.dp),

        ) {
            Image(
                painter = painterResource(jurusan.photoJurusan),
                contentDescription = "Jurusan Image",
                modifier = Modifier
                    .size(170.dp)
                    .clip(shape = MaterialTheme.shapes.medium),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.height(16.dp))

            Column(modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, top = 15.dp, bottom = 10.dp, end = 10.dp)
                ,) {
                Text(
                    text = jurusan.namaJurusan,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                )
                Text(
                    text = jurusan.fakultas,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 25.dp)
                )
            }

        }

        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(start = 30.dp, top = 25.dp, end = 10.dp, bottom = 25.dp),) {

            Text(
                text = stringResource(id = jurusan.detailInfoJurusan),
                modifier = Modifier.fillMaxWidth()
            )

        }

        LazyRow(
            modifier = Modifier
                .padding(start = 10.dp, end = 5.dp)
                .fillMaxWidth()
        ) {
            items(DataUniversitas.infoUniversitas) { universitas ->
                UniversitasItem(universitas) {
                    val intent = Intent(context, DetailActivity::class.java)
                    intent.putExtra("universitas", universitas)
                    context.startActivity(intent)
                }
            }
        }

        Button(
            onClick = onBackClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Text(text = "Back")
        }
    }
}

@Composable
fun UniversitasItem(universitas: Universitas, onItemClick:() -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .padding(vertical = 8.dp)
            .clickable(onClick = onItemClick)
    ) {
        Image(
            painter = painterResource(id = universitas.photoUniversitas),
            contentDescription = "Universitas Photo",
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier.padding(start = 16.dp)
        ) {
            Text(
                text = universitas.namaUniversitas,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = universitas.Daerah
            )
        }
    }
}
