package com.example.jurusancompose.navigation

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jurusancompose.main.DetailActivity
import com.example.jurusancompose.model.DataJurusan
import com.example.jurusancompose.model.Jurusan
import com.example.jurusancompose.ui.theme.JurusanComposeTheme

@Composable
fun HomeScreen() {
    val selectedJurusan = remember { mutableStateOf<Jurusan?>(null)}
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.padding(16.dp)
    ) {
        items(DataJurusan.infoJurusan) { jurusan ->
            JurusanItem(jurusan) {
                val intent = Intent(context, DetailActivity::class.java)
                intent.putExtra("jurusan", jurusan)
                context.startActivity(intent)
            }
        }
    }

    if (selectedJurusan.value != null) {
        DetailJurusanScreen(selectedJurusan.value!!) {
            selectedJurusan.value = null
        }
    }
}


@Composable
fun JurusanItem(jurusan: Jurusan, onItemClick:() -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .padding(vertical = 8.dp)
            .clickable(onClick = onItemClick)
    ) {
        Image(
            painter = painterResource(id = jurusan.photoJurusan),
            contentDescription = "Jurusan Photo",
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier.padding(start = 16.dp)
        ) {
            Text(
                text = jurusan.namaJurusan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = jurusan.fakultas
            )
            Text(
                text = stringResource(id = jurusan.detailInfoJurusan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            )
        }
    }
}

@Preview
@Composable
fun PreviewHomeScreen() {
    JurusanComposeTheme {
        HomeScreen()
    }
}