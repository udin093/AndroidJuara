package com.example.jurusancompose.model

import com.example.jurusancompose.R

import android.os.Parcel
import android.os.Parcelable

data class Jurusan(
    val namaJurusan: String,
    val fakultas: String,
    val detailInfoJurusan: Int,
    val photoJurusan: Int
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(namaJurusan)
        parcel.writeString(fakultas)
        parcel.writeInt(detailInfoJurusan)
        parcel.writeInt(photoJurusan)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Jurusan> {
        override fun createFromParcel(parcel: Parcel): Jurusan {
            return Jurusan(parcel)
        }

        override fun newArray(size: Int): Array<Jurusan?> {
            return arrayOfNulls(size)
        }
    }
}


object DataJurusan {
    val infoJurusan = listOf(
        Jurusan(
            "Teknik Komputer",
            "Teknologi Informasi",
            R.string.detailTeknikKomputer,
            R.drawable.teknikkomputer
        ),
        Jurusan(
            "Manajement Bisnis",
            "Fakultas Ekonomi Bisnis",
            R.string.detailManagementBisnis,
            R.drawable.managementbisnis
        ),
        Jurusan(
            "Keuangan",
            "Fakultas Ekonomi Bisnis",
            R.string.detailKeuangan,
            R.drawable.keuangan
        ),
        Jurusan(
            "Ekonomi",
            "Fakultas Ekonomi Bisnis",
            R.string.detailEkonomi,
            R.drawable.ekonomi
        ),
        Jurusan(
            "Biologi",
            "Fakultas MIPA",
            R.string.detailBilogi,
            R.drawable.biologi
        ),
        Jurusan(
            "Kimia",
            "Fakultas MIPA",
            R.string.detailKimia,
            R.drawable.kimia
        ),
        Jurusan(
            "Fisika",
            "Fakultas MIPA",
            R.string.detailFisika,
            R.drawable.fisika
        ),
        Jurusan(
            "Geografi",
            "Fakultas MIPA",
            R.string.detailGeografi,
            R.drawable.geografi
        ),
        Jurusan(
            "Sistem Informasi",
            "Fakultas Teknologi Informasi",
            R.string.detailSistemInformasi,
            R.drawable.sisteminformasi
        ),
        Jurusan(
            "Teknik Sipil",
            "Fakultas Teknik",
            R.string.detailTeknikSipil,
            R.drawable.tekniksipil
        ),
        Jurusan(
            "Teknik Lingkungan",
            "Fakultas Teknik",
            R.string.detailTekniklingkungan,
            R.drawable.tekniklingkungan
        ),
        Jurusan(
            "Teknik Industri",
            "Fakultas Teknik",
            R.string.detailTeknikIndustri,
            R.drawable.teknikindustri
        ),
        Jurusan(
            "Ilmu Komunikasi",
            "Fakultas Ilmu Sosial Politik",
            R.string.detailIlmuKomunikasi,
            R.drawable.ilmukomunikasi
        ),
        Jurusan(
            "Sosiologi",
            "Fakultas Ilmu Sosial Politik",
            R.string.detailSosiologi,
            R.drawable.sosiologi
        ),
    )
}