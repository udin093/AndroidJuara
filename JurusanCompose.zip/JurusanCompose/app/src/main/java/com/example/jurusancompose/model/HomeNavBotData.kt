package com.example.jurusancompose.model

import androidx.compose.ui.graphics.vector.ImageVector

sealed class ScreenNav(val route: String){
    object Home : ScreenNav("home")
    object Profile : ScreenNav("profile")
}

data class ScreenNavItem(
    val title: String,
    val icon: ImageVector,
    val screen: ScreenNav
)

