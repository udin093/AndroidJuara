package com.example.jurusancompose.navigation

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.jurusancompose.R
import com.example.jurusancompose.ui.theme.JurusanComposeTheme
import androidx.compose.material3.MaterialTheme
@Composable
fun ProfileScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val photoProfile = painterResource(R.drawable.khalidphoto)
        val namaLengkap = "M.Khalid Assiddiq"
        val email = "a137dkx4019@bangkit.academy"
        val deskripsiUser = "Bangkit Academy Student 2023 for Android Development"

        Image(
            painter = photoProfile,
            contentDescription = "Profile Photo",
            modifier = Modifier
                .size(200.dp)
                .clip(shape = MaterialTheme.shapes.medium),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = namaLengkap,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = email,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = deskripsiUser,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold
        )
    }
}

@Preview
@Composable
fun PreviewProfileScreen() {
    JurusanComposeTheme {
        ProfileScreen()
    }
}