package com.example.jurusancompose.main

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.jurusancompose.model.Jurusan
import com.example.jurusancompose.navigation.DetailJurusanScreen
import com.example.jurusancompose.ui.theme.JurusanComposeTheme

class DetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val jurusan = intent.getParcelableExtra<Jurusan>("jurusan")

        if (jurusan != null) {
            setContent {
                JurusanComposeTheme {
                    DetailJurusanScreen(jurusan) {
                        finish()
                    }
                }
            }
        } else {
            finish()
        }
    }
}